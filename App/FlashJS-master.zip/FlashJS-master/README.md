FLASH JS
========

<a href="http://pixelscommander.com/polygon/skateboarding/">See it in action</a>

FlashJS is JavaScript graphics and game development engine with API similar to Flash one.
It`s HTML5 game development tool, based on verified for years Flash methodology.
Just write ActionScript 3 code inside of <actionscript> tag.

To get started -- checkout http://github.com/PixelsCommander/FlashJS


Usage
-----

You can use FlashJS for applications or game development.

Start from analyzing examples.


Bug tracker
-----------

Have a bug? Please create an issue here on GitHub!

https://github.com/PixelsCommander/FlashJS/issues


Twitter account
---------------

Keep up to date on announcements and more by following FlashJS on Twitter, <a href="http://twitter.com/flashjslib">@flashjslib</a>.


Mailing list
------------

Have a question? Ask on our mailing list!

flashjs@googlegroups.com

http://groups.google.com/group/flashjs


License
---------------------

Copyright 2011 Denis Radin.

Licensed under the Apache License, Version 2.0: http://www.apache.org/licenses/LICENSE-2.0
