# Bootstrap v3 datetimepicker widget ![GitHub version](https://badge.fury.io/gh/Eonasdan%2Fbootstrap-datetimepicker.png)&nbsp;&nbsp;&nbsp;![Travis](https://travis-ci.org/Eonasdan/bootstrap-datetimepicker.svg?branch=development)

![DateTimePicker](http://i.imgur.com/nfnvh5g.png)

## [View the manual and demos](http://eonasdan.github.io/bootstrap-datetimepicker/)

## Submitting Issues
Please test and/or fork [this jsfiddle](http://jsfiddle.net/kmbo576p/) with an example of your issue before you post an issue here. 

## Where do you use this?
I'd love to know if your public site is using this plugin and list your logo on the documentation site. Please email me `eonasdan at outlook dot com`. Do not submit issue/feature request to this email, they will be ignored.

## [Installation instructions](https://github.com/Eonasdan/bootstrap-datetimepicker/wiki/Installation)
Installation instructions has been moved to the wiki

## [Change Log](https://github.com/Eonasdan/bootstrap-datetimepicker/wiki/Change-Log)
The change log has moved to the wiki
