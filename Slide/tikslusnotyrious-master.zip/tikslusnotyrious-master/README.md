Tikslus Notirious
=============

Jquery based Notification plugin.
Comes with following features:
1. 7 pre defined themes.
2. dispatch multiple messages at once.
3. use images in messages.
4. show progress bar is message is non sticky.
5. Use custom defined buttons and function callbacks. 


Visit http://tikslus.com/tikslusnotyrious for a demo
